﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Calc_inerface
{
    /// <summary>
    /// Логика взаимодействия для Params.xaml
    /// </summary>
    public partial class Params : Window
    {
        private bool _close;
        MainWindow wnd1 = null;
        public double InpA, InpB, InpC;
        public bool InpCancel;

        public Params()
        {
            InitializeComponent();
            txtA.Text = "";
            txtB.Text = "";
            txtC.Text = "";
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if ((txtA.Text == "") && (txtB.Text == "") && (txtC.Text == ""))
            {
                InpCancel = true;
            }
            //if (_close) return;
            e.Cancel = true;
            Hide();

        }

        public new void Close()
        {
            _close = true;
            base.Close();
        }

        private void txtA_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = e.Text.All(Char.IsLetter);
        }

        private void txtB_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = e.Text.All(Char.IsLetter);
        }

        private void txtC_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtC_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = e.Text.All(Char.IsLetter);
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            wnd1 = Owner as MainWindow;
            try
            {
                InpA = double.Parse(txtA.Text.Replace('.', ','));
                InpB = double.Parse(txtB.Text.Replace('.', ','));
                InpC = double.Parse(txtC.Text.Replace('.', ','));
                InpCancel = false;
               this.DialogResult = true;
                e.Handled = true;
            }
            catch (FormatException)
            {
                MessageBox.Show("Неверный формат введенных данных!");
                e.Handled=false;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
             InpCancel = true;
            this.DialogResult = false;
        }
    }
}
