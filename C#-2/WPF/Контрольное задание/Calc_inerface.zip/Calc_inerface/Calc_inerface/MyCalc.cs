﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Calc_inerface
{
    public class MyCalc
    {
        public MyCalc() { }
        public double pA, pB, pC;
        public int cntMem;
        public string operType;
        public string operTypeNew;
        public string operTypeOne;

        public double SetAdd(double p1, double p2) => p1 + p2;
        public double SetSub(double p1, double p2) => p1 - p2;
        public double SetMult(double p1, double p2) => p1 * p2;
        public double? SetDev(double p1, double p2)
        {
            if (p2 == 0)
            { return null; }
            else
            { return p1 / p2; }
        }
        public double SetDegree(double p1, double p2) => Math.Pow(p1, p2);

        public double SetSqrt(double p1) => Math.Sqrt(p1);
        public double? SetInv(double p1)
        {
            if (p1 == 0)
            { return null; }
            else
            { return 1 / p1; }
        }
        public double SetSqr(double p1) =>p1*p1;

        public double? Calc()
        {
            switch (operType)
            {
                case "ADD":
                    return SetAdd(pA, pB);
                    break;
                case "SUB":
                    return SetSub(pA, pB);
                    break ;
                case "MULT":
                    return SetMult(pA, pB);
                    break;
                case "DEV":
                    return SetDev(pA, pB);
                    break;
                case "DEGR":
                    return SetDegree(pA, pB);
                    break;
            }
            return null;
        }
        public double? CalcOne(double x)
        {
            switch (operTypeOne) 
            {
                case "SQRT":
                    return SetSqrt(x);
                    break;
                case "INV":
                    return SetInv(x);
                    break;
                case "SQR":
                    return SetSqr(x);
                    break;
                case "FACT":
                    return Factorial(x);
                    break;
                case "CUBE":
                    return CubeRoot(x);
                    break;
            }
            return null;
        }

        public static double CubeRoot(double a)
        {
            //используется метод Ньютона для поиска корня уравнения x*x*x-a=0

            if (a == 0) return 0;
            double x = a > 0 ? a : -a; // Начальное приближение
            double prevX = 0;

            // Итерационный процесс
            for (int i = 0; i < 100; i++)
            {
                prevX = x;
                x = (2.0 * x + a / (x * x)) / 3.0;
                if (Math.Abs(x - prevX) < 1e-10) break; // Точность
            }
            return a > 0 ? x : -x;
        }

        double Factorial(double n)
        {
            long result = 1;
            for (int i = 1; i <= n; i++) result *= i;
            return result;
        }

        public string QuadEquation()
        {
            // double a = 1, b = -3, c = 2; 
            if ((pA == 0) && (pB !=0))
            {
                double x = -pC / pB;
                return $"Один корень: x = {x}";
            }
            if ((pA == 0) && (pB == 0) && (pC==0))
            {
                return "x любое число";
            }
            double d = pB * pB - 4 * pA * pC;

            if (d > 0)
            {
                double x1 = (-pB + Math.Sqrt(d)) / (2 * pA);
                double x2 = (-pB - Math.Sqrt(d)) / (2 * pA);
                return $"Два корня: x1 = {x1}, \nx2 = {x2}";
            }
            else if (d == 0)
            {
                double x = -pB / (2 * pA);
               return $"Один корень: x = {x}";
            }
            else
            {
                return "Действительных корней нет (D < 0)";
            }
        }
    }
}
