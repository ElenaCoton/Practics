﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.SqlServer.Server;
using static System.Net.Mime.MediaTypeNames;


namespace Calc_inerface
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        MyCalc helper = new MyCalc();
       public Params myPar { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            m_simp.IsEnabled = false;
            m_ing.IsEnabled = true;
            ButGrid.ColumnDefinitions[4].Width = new GridLength(0);
        }

        private void Equation_Handler(object sender, ExecutedRoutedEventArgs e)
        {
            if (myPar == null)
                myPar = new Params();
            myPar.Owner = this;
            myPar.Show();
        }

        private void MenuItem_Smp(object sender, RoutedEventArgs e)
        {
            ButGrid.ColumnDefinitions[4].Width = new GridLength(0);
            m_simp.IsEnabled = false;
            m_ing.IsEnabled = true;
        }

        private void MenuItem_Ing(object sender, RoutedEventArgs e)
        {
            ButGrid.ColumnDefinitions[4].Width = GridLength.Auto;
            m_simp.IsEnabled = true;
            m_ing.IsEnabled = false;
            bFact.Width = 130;
        }

        private void ExitCom_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private void Clear()
        {
            if (myDisplay.Text.Any(Char.IsLetter))
            {
                 helper.cntMem = 0;
                 helper.pA = 0;
                 helper.pB = 0;
                 myDisplay.Text = "";
            }
        }

        
        private void itemHelp_Click(object sender, RoutedEventArgs e)
        {
            lHelp.Content = "Контрольное задание";
              DoubleAnimation animation = new DoubleAnimation
              {
                  From = 1.0,
                  To = 0.0,
                  Duration = new Duration(TimeSpan.FromSeconds(1)),
                  BeginTime = TimeSpan.FromSeconds(3) // Задержка перед началом
              };
            lHelp.BeginAnimation(TextBlock.OpacityProperty, animation);

           
        }

        private void Grid_Click(object sender, RoutedEventArgs e)
        {
            FrameworkElement feSource = e.Source as FrameworkElement;
            Button btn;
            btn = (Button)feSource;
            double? res;
            double res2;
            //LOper.BeginAnimation(UIElement.OpacityProperty, null);
            try
            {

                if ((feSource.Name == "b0") || (feSource.Name == "b1") || (feSource.Name == "b2") || (feSource.Name == "b3") ||
                    (feSource.Name == "b4") || (feSource.Name == "b5") || (feSource.Name == "b6") || (feSource.Name == "b7") ||
                    (feSource.Name == "b8") || (feSource.Name == "b9"))
                {
                   Clear();
                    myDisplay.Text = myDisplay.Text + btn.Content.ToString();
                }
                else if (feSource.Name == "bZpt")
                {

                    if (myDisplay.Text.Length == 0)
                    {
                        myDisplay.Text = "0,";
                    }
                    else
                    {
                        myDisplay.Text = myDisplay.Text + ",";
                    }
                }
                else if (feSource.Name == "bC")
                {
                    if (myDisplay.Text.Length != 0)
                    {
                        myDisplay.Text = myDisplay.Text.Substring(0, myDisplay.Text.Length - 1);
                    }
                }
                else if (feSource.Name == "bClear")
                {
                    helper.cntMem = 0;
                    helper.pA = 0;
                    helper.pB = 0;
                    myDisplay.Text = "";
                }
                else if (feSource.Name == "bSign")
                {
                    if (myDisplay.Text.Length != 0)
                    {
                        if (myDisplay.Text.Substring(0, 1) == "-")
                        {
                            myDisplay.Text = myDisplay.Text.Substring(1, myDisplay.Text.Length - 1);
                        }
                        else 
                        {
                            myDisplay.Text = "-" + myDisplay.Text;
                        }
                    }
                }
                if ((feSource.Name == "bPlus") || (feSource.Name == "bMinus") || (feSource.Name == "bMult") || (feSource.Name == "bDev") || (feSource.Name == "bDegr"))
                {
                    if (myDisplay.Text.Length != 0)
                    {
                        // if (double.TryParse(myDisplay.Text, out helper.pA))
                        if (double.TryParse(myDisplay.Text,  out res2))
                        {
                            myDisplay.Text = "";
                            helper.cntMem = helper.cntMem + 1;
                            switch (feSource.Name)
                            {
                                case "bPlus":
                                    //helper.operType = "ADD";
                                    helper.operTypeNew = "ADD";
                                    LOper.Content = "+";
                                    break;
                                case "bMinus":
                                    //helper.operType = "SUB";
                                    helper.operTypeNew = "SUB";
                                    LOper.Content = "-";
                                    break;
                                case "bMult":
                                    //helper.operType = "MULT";
                                    helper.operTypeNew = "MULT";
                                    LOper.Content = "*";
                                    break;
                                case "bDev":
                                    //helper.operType = "DEV";
                                    helper.operTypeNew = "DEV";
                                    LOper.Content = "/";
                                    break;
                                case "bDegr":
                                    //helper.operType = "DEGR";
                                    helper.operTypeNew = "DEGR";
                                    LOper.Content = "Степень";
                                    break;
                            }
                            if (helper.cntMem == 1) { helper.pA = res2; helper.operType = helper.operTypeNew; } else { helper.pB = res2; }
                            if (helper.cntMem == 2)
                            {
                                res = helper.Calc();
                                if (res == null)
                                {
                                    myDisplay.Text = "ERROR";
                                }
                                else
                                {
                                    helper.pA = (double)res;
                                    helper.pB = 0;
                                }
                                helper.operType = helper.operTypeNew;
                                helper.cntMem = 1;
                            }
                            
                        }
                    }
                }
                if ((feSource.Name == "bSqrt") || (feSource.Name == "bInv") || (feSource.Name == "bSq") || 
                    (feSource.Name == "bFact") || (feSource.Name == "bCube"))
                {
                    if (myDisplay.Text.Length != 0)
                    {
                        if (double.TryParse(myDisplay.Text, out res2))
                        {
                            switch (feSource.Name)
                            {
                                case "bSqrt":
                                    helper.operTypeOne = "SQRT";
                                    break;
                                case "bInv":
                                    helper.operTypeOne = "INV";
                                    break;
                                case "bSq":
                                    helper.operTypeOne = "SQR";
                                    break;
                                case "bFact":
                                    helper.operTypeOne = "FACT";
                                    break;
                                case "bCube":
                                    helper.operTypeOne = "CUBE";
                                    break;
                            }
                            res = helper.CalcOne(res2);
                            if (res == null) { myDisplay.Text = "ERROR"; }
                            else
                            {
                                if (helper.cntMem == 0)
                                {
                                    helper.pA = (double)res;
                                    myDisplay.Text = res.ToString();
                                }
                                else
                                {
                                    helper.pB = (double)res;
                                    myDisplay.Text = res.ToString();
                                }
                            }
                        }
                    }
                }
                else if (feSource.Name == "bEqu")
                {
                    LOper.Content = "";
                    if ((myDisplay.Text.Length != 0) && (helper.cntMem == 1))
                    {
                        if (double.TryParse(myDisplay.Text, out helper.pB))
                        {
                            res = helper.Calc();
                            if (res == null)
                            {
                                myDisplay.Text = "ERROR";
                            }
                            else
                            {
                                myDisplay.Text = res.ToString();
                                helper.cntMem = 0;
                                helper.pA = (double)res;
                                helper.pB = 0;
                            }
                        }
                    }
                }

                e.Handled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void bE_Click(object sender, RoutedEventArgs e)
        {
            if (myPar == null)
                myPar = new Params();
            myPar.Owner = this;
            myPar.txtA.Text = "";
            myPar.txtB.Text = "";
            myPar.txtC.Text = "";
            myDisplay.Text = "";

            myPar.ShowDialog();
          

            if (!myPar.InpCancel)
            {
                helper.pA = myPar.InpA;
                helper.pA = myPar.InpA;
                helper.pB = myPar.InpB;
                helper.pC = myPar.InpC;
                myDisplay.Text = helper.QuadEquation();
            }
            
        }
    }
}
